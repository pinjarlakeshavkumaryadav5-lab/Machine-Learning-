import librosa
import soundfile
import numpy as np

from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

def extract_feature(file_name):

    with soundfile.SoundFile(file_name) as sound:

        audio = sound.read(dtype="float32")

        sample_rate = sound.samplerate

        mfcc = np.mean(
            librosa.feature.mfcc(
                y=audio,
                sr=sample_rate,
                n_mfcc=40
            ).T,
            axis=0
        )

    return mfcc

print("Emotion Recognition Project Ready")