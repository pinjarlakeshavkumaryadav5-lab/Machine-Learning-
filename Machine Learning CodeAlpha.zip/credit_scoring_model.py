import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

data = {
    "income": [50000, 20000, 30000, 80000, 100000],
    "loan": [10000, 15000, 12000, 20000, 25000],
    "credit_score": [700, 500, 650, 800, 750],
    "approved": [1, 0, 1, 1, 1]
}

df = pd.DataFrame(data)

X = df[["income", "loan", "credit_score"]]
y = df["approved"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2
)

model = LogisticRegression()

model.fit(X_train, y_train)

predictions = model.predict(X_test)

print("Predictions:", predictions)

accuracy = accuracy_score(y_test, predictions)

print("Accuracy:", accuracy)