import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

data = {
    "age": [25, 40, 35, 50, 60],
    "bp": [120, 140, 130, 150, 160],
    "sugar": [80, 120, 100, 140, 150],
    "disease": [0, 1, 0, 1, 1]
}

df = pd.DataFrame(data)

X = df[["age", "bp", "sugar"]]
y = df["disease"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2
)

model = RandomForestClassifier()

model.fit(X_train, y_train)

predictions = model.predict(X_test)

accuracy = accuracy_score(y_test, predictions)

print("Accuracy:", accuracy)